﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Dialogs.Choices;
using System;
using System.IO;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;

namespace Microsoft.BotBuilderSamples
{
    public class UserProfileDialog : ComponentDialog
    {
        private readonly IStatePropertyAccessor<UserProfile> _userProfileAccessor;

        public UserProfileDialog(UserState userState)
            : base(nameof(UserProfileDialog))
        {
            _userProfileAccessor = userState.CreateProperty<UserProfile>("UserProfile");

            // This array defines how the Waterfall will execute.
            var waterfallSteps = new WaterfallStep[]
            {
                N1,
                ApproveIt,
                NumberofRequest,
                ApproveRequest,
                ApproveDoc,
                Transport,
                ApproveEducation,
                Trainers,
                Ask2,
                Perform,


            };


            // Add named dialogs to the DialogSet. These names are saved in the dialog state.
            AddDialog(new WaterfallDialog(nameof(WaterfallDialog), waterfallSteps));
            AddDialog(new TextPrompt(nameof(TextPrompt)));
            AddDialog(new ChoicePrompt(nameof(ChoicePrompt)));
            AddDialog(new ConfirmPrompt(nameof(ConfirmPrompt)));

            // The initial child Dialog to run.
            InitialDialogId = nameof(WaterfallDialog);
        }

        //Yıllık izin girmek istiyorum.

        private static async Task<DialogTurnResult> N1(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Mevcut izin bakiyen 5 gün, hangi tarihler için izin almak istiyorsun?") }, cancellationToken);
        }



        /*
        private async Task<DialogTurnResult> NameConfirmStepAsync(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            //stepContext.Values["name"] = (string)stepContext.Result;

            // We can send messages to the user at any point in the WaterfallStep.
            await stepContext.Context.SendActivityAsync(MessageFactory.Text($"Mevcut izin bakiyen 5 gün, hangi tarihler için izin almak istiyorsun?"), cancellationToken);

            // WaterfallStep always finishes with the end of the Waterfall or with another dialog; here it is a Prompt Dialog.
            return await stepContext.PromptAsync(nameof(ConfirmPrompt), new PromptOptions { Prompt = MessageFactory.Text("Size yardımcı olmamı ister misiniz?") }, cancellationToken);
        }
        */

        private static async Task<DialogTurnResult> ApproveIt(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            return await stepContext.PromptAsync(nameof(ChoicePrompt),
                            new PromptOptions
                            {

                                Prompt = MessageFactory.Text("28.06.2019 tarihli 1 günlük izin talebini oluşturdum, onaya gönderiyorum onaylıyor musun?"),
                                Choices = ChoiceFactory.ToChoices(new List<string> { "Evet", "Hayır" }),
                            }, cancellationToken);
        }



        private static async Task<DialogTurnResult> NumberofRequest(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            //stepContext.Values["transfer"] = (string)stepContext.Result;

            // We can send messages to the user at any point in the WaterfallStep.


            // WaterfallStep always finishes with the end of the Waterfall or with another dialog; here it is a Prompt Dialog.
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("4 gün yıllık izin bakiyen kaldı. Senin için farklı ne işlem yapabilirim?") }, cancellationToken);
        }

        //Onaylanacak fatura/izin var mı?

        private static async Task<DialogTurnResult> ApproveRequest(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            var cardAttachment = CreateAdaptiveCardAttachment("C:/Users/t-daalka/Downloads/BotBuilder-Samples-master/BotBuilder-Samples-master/samples/csharp_dotnetcore/07.using-adaptive-cards/Resources/izin.json");

            await stepContext.Context.SendActivityAsync(MessageFactory.Attachment(cardAttachment), cancellationToken);

            return await stepContext.PromptAsync(nameof(ChoicePrompt),
                            new PromptOptions
                            {

                                Prompt = MessageFactory.Text("Ekibinden Irmak Şişmanoğlu yıllık izin talebinde bulunmuş, onaylıyor musun?"),
                                Choices = ChoiceFactory.ToChoices(new List<string> { "Evet", "Hayır" }),
                            }, cancellationToken);
        }

       
            
        private static async Task<DialogTurnResult> ApproveDoc(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            await stepContext.Context.SendActivityAsync(MessageFactory.Text("Irmak Şişmanoğlu'nun yıllık izin talebini onayladın."), cancellationToken);
            await stepContext.Context.SendActivityAsync(MessageFactory.Text("Onayda bekleyen 1 adet ZER/KS faturası onaylanması için linke tıkla: https://startdev.arcelik.com/ApplicationBuilder/eFormRender.html?Process=Invoice%20Portal  "), cancellationToken);

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Senin için başka ne işlem yapabilirim?") }, cancellationToken);
        }




        // Sütlüce'den Çayırova'ya nasıl gidebilirim?

        private static async Task<DialogTurnResult> Transport(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            await stepContext.Context.SendActivityAsync(MessageFactory.Text("Sütlüce'den Çayırova'ya 11.00'de ring servisi bulunuyor ya da Araç İste'den araç talebi açtırmak için linke tıkla:  https://araciste.koczer.com"), cancellationToken);
            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Senin için başka ne işlem yapabilirim?") }, cancellationToken);
        }

        //Bugün yemekte ne var? Bugün Çayırova'da yemekte ne var?


        //Eğitim içeriği sorgulama

        private static async Task<DialogTurnResult> ApproveEducation(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {
            var cardAttachment2 = CreateAdaptiveCardAttachment("C:/Users/t-daalka/Downloads/BotBuilder-Samples-master/BotBuilder-Samples-master/samples/csharp_dotnetcore/07.using-adaptive-cards/Resources/Domates_corbasi.json");
            await stepContext.Context.SendActivityAsync(MessageFactory.Attachment(cardAttachment2), cancellationToken);
            //await stepContext.Context.SendActivityAsync(MessageFactory.Text("Domates Çorba(173 Kcal), Piliç Şinitzel(230 Kcal), Spagetti Makarna(319 Kcal), Mozaik Pasta(320 Kcal), Salata Bar"), cancellationToken);

            return await stepContext.PromptAsync(nameof(ChoicePrompt),
                            new PromptOptions
                            {

                                Prompt = MessageFactory.Text("Gelecek ayki eğitimlere göz atmak ister misin? "),
                                Choices = ChoiceFactory.ToChoices(new List<string> { "Evet", "Hayır" }),
                            }, cancellationToken);
        }


        // Eğitimleri göster

        private static async Task<DialogTurnResult> Trainers(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            var cardAttachment3 = CreateAdaptiveCardAttachment("C:/Users/t-daalka/Downloads/BotBuilder-Samples-master/BotBuilder-Samples-master/samples/csharp_dotnetcore/07.using-adaptive-cards/Resources/Kemal_Islamoglu.json");

            await stepContext.Context.SendActivityAsync(MessageFactory.Attachment(cardAttachment3), cancellationToken);

            //var cardAttachment4 = CreateAdaptiveCardAttachment("C:/Users/t-daalka/Downloads/BotBuilder-Samples-master/BotBuilder-Samples-master/samples/csharp_dotnetcore/07.using-adaptive-cards/Resources/Yeliz_Kum_Ercan.json");

            //await stepContext.Context.SendActivityAsync(MessageFactory.Attachment(cardAttachment4), cancellationToken);

            return await stepContext.PromptAsync(nameof(ChoicePrompt),
                            new PromptOptions
                            {

                                Prompt = MessageFactory.Text("Bu eğitime katılmak ister misin?"),
                                Choices = ChoiceFactory.ToChoices(new List<string> { "Evet", "Hayır" }),
                            }, cancellationToken);
        }



        //Performans takvimi

        private static async Task<DialogTurnResult> Ask2(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Senin için farklı ne işlem yapabilirim?") }, cancellationToken);
        }

        private static async Task<DialogTurnResult> Perform(WaterfallStepContext stepContext, CancellationToken cancellationToken)
        {

            return await stepContext.PromptAsync(nameof(TextPrompt), new PromptOptions { Prompt = MessageFactory.Text("Temmuz ayında ara dönem performans görüşmelerinin tamamlanması gerekiyor.Detaylı bilgi için linke tıkla") }, cancellationToken);
        }
        private static Attachment CreateAdaptiveCardAttachment(string filePath)
        {
            var adaptiveCardJson = File.ReadAllText(filePath);
            var adaptiveCardAttachment = new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(adaptiveCardJson),
            };
            return adaptiveCardAttachment;
        }

        /// <summary>

        /// </summary>
        /// <param name="stepContext"></param>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>














    



    }
}
